﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CountDown : MonoBehaviour {

    // Use this for initialization
    public int s_num;
    private int StartingNumber=0;
    string num;
    public GameObject[] Numbers;
    float timeStep = 1.0f;
   public float startTime = 1;
    int numCount = 10
        ;
    Vector3 stuff;
    void Start () {

        //Destroy(GameObject.Find("10(Clone)"));

    }
	
	// Update is called once per frame
	void FixedUpdate () {
        startTime -= Time.deltaTime;
        this.transform.Rotate(0, 100 * Time.deltaTime, 0);
       

        if (startTime <= 0f)
        {
            //  Debug.Log(temp.ToString() + ("(Clone)"));
            int temp = numCount;
            if(GameObject.FindGameObjectWithTag(numCount.ToString())==null)        
            {
               
            }
            else
            {
                Destroy(GameObject.FindGameObjectWithTag(temp.ToString()));
                numCount--;
            }
            Instantiate(Numbers[numCount], this.transform.position + stuff, this.transform.rotation);
            
            GameObject.FindGameObjectWithTag(numCount.ToString()).transform.parent = this.gameObject.transform;
            
            startTime=1; ;
        }
    }
}
