﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
public class Hill : NetworkBehaviour {
    [SyncVar]
    public float timer;
    public GameObject CD;
    bool doOnce = false;
    bool doOnceb = false;
    bool doOncec = false;
    public GameObject GMNG;
	// Use this for initialization
	void Start () {
        GMNG = GameObject.FindGameObjectWithTag("GameController");
	}

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 11)
        {
            transform.GetChild(0).transform.localScale -= new Vector3(0.001f, 0.001f, 0.001f);
            this.transform.localScale -= new Vector3(0.01f, 0.00f, 0.01f);
            if (!doOnce)
            {
                Instantiate(CD, this.transform.position+new Vector3(0,3,0), this.transform.rotation);
                
                GameObject.FindGameObjectWithTag("Respawn").gameObject.transform.parent = this.gameObject.transform;
                doOnce = true;
            }
        }
        if(timer<0)
        {
            
            Destroy(this.gameObject);
        }
    }
    private void OnTriggerEnter(Collider other)
    {

        if (other.gameObject.tag == "Player")
        {

            Debug.Log(other.gameObject.name + "is king");
                other.GetComponent<PlayerUnit>().isKing = true;
                           
            
        }

    }
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
          
               

            other.GetComponent<PlayerUnit>().isKing = false;
           
        }
    }
}
