﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Player : NetworkBehaviour {

    #region NonNetworked variables
    public GameObject pShield=null;
    public Camera pCamera=null;
   
    public bool isKing=false;
    public bool isControled = false;
    private Vector3 sheiledStartPos;

    [SerializeField]
    private float maxShieldDistance;
    [SerializeField]
    private float maxShieldSpeed;
    [SerializeField]
    private float maxMovementspeed;
    [SerializeField]
    private float maxRotationSpeed;
    public float strafeSpeed;
    float forwardSpeed;
    private Vector3 horizontalVelocity;
    private Vector3 sheildVelocity;
    bool doOnce = false;
    bool doOnceB = false;

    #endregion
    #region Networked variables
    //[SyncVar]
    public int score = 0;
    #endregion
    // Use this for initialization
    void Start () {
        pShield = this.transform.GetChild(0).gameObject;
        pCamera = this.transform.GetChild(1).gameObject.GetComponent<Camera>();
        sheiledStartPos = pShield.transform.localPosition;
       // Debug.Log(sheiledStartPos);
	}

    // Update is called once per frame
    void Update() {

       // if (isControled)
        
       
        if(isKing)
        {
            if(!doOnce)
            {
                GameObject.FindGameObjectWithTag("GameController").GetComponent<GameManager>().playerOnhill ++ ;
                doOnce = true;
            }
            doOnceB = false;
        }
        else if(!isKing)
        {
            if(!doOnceB)
            {
                if (GameObject.FindGameObjectWithTag("GameController").GetComponent<GameManager>().playerOnhill > 0)
                {
                    GameObject.FindGameObjectWithTag("GameController").GetComponent<GameManager>().playerOnhill --;
                    doOnceB = true;
                }
            }
            doOnce = false;
        }
        

    }

    void FixedUpdate()
    {

        if (this.GetComponent<NetworkIdentity>().hasAuthority)
        {
            this.transform.Rotate(0, Input.GetAxis("Mouse X") * Time.deltaTime * maxRotationSpeed, 0);
            CmdsheildCheck();
            CmdprocessInput();
            CmdshieldPush();
        }
       
    }
    [Command]
    void CmdprocessInput()
    {

       
            float forwardSpeed = Input.GetKey(KeyCode.W) ? maxMovementspeed : 0.0f;
            float backwardSpeed = Input.GetKey(KeyCode.S) ? -maxMovementspeed : 0.0f;
            float strafeLeft = Input.GetKey(KeyCode.A) ? -maxMovementspeed : 0.0f;
            float strafeRight = Input.GetKey(KeyCode.D) ? maxMovementspeed : 0.0f;
            strafeSpeed = strafeLeft + strafeRight;
            float totalSpeed = forwardSpeed + backwardSpeed;
            horizontalVelocity = (totalSpeed * transform.forward) + ((strafeSpeed) * transform.right);
            this.GetComponent<Rigidbody>().velocity = horizontalVelocity;
        
    }
    [Command]
    void CmdsheildCheck()
    {
        if (pShield.transform.localPosition.z >= 1.5)
        {
            pShield.transform.localPosition = new Vector3(0, 0, 1.5f);
        }
        else if(pShield.transform.localPosition.x>=sheiledStartPos.x|| pShield.transform.localPosition.x <= sheiledStartPos.x)
        {
            pShield.transform.localPosition = new Vector3(sheiledStartPos.x,0,pShield.transform.localPosition.z);
        }
        if(forwardSpeed==0)
        {
            CmdsheildLock();
        }
       
    }
    [Command]
    void CmdsheildLock()
    {
        Rigidbody r = pShield.GetComponent<Rigidbody>();
        r.constraints = RigidbodyConstraints.FreezeAll;

    }
    [Command]
    void CmdsheildUnLock()
    {
        Rigidbody r = pShield.GetComponent<Rigidbody>();
        r.constraints = RigidbodyConstraints.FreezePositionY;
        r.constraints = RigidbodyConstraints.FreezePositionX;
        r.constraints = RigidbodyConstraints.FreezeRotation;

    }

    [Command]
    void CmdshieldPush()
    {
       forwardSpeed=0;
        
        if(Input.GetMouseButton(0))
        {
            
           
             forwardSpeed = maxMovementspeed;
            CmdsheildUnLock();
        }
        else
        {
            pShield.transform.position = this.transform.GetChild(3).transform.position;
            forwardSpeed = 0;
            CmdsheildLock();
        }
        
        sheildVelocity = transform.forward * forwardSpeed;
        pShield.GetComponent<Rigidbody>().velocity = this.GetComponent<Rigidbody>().velocity + sheildVelocity;
        if (pShield.transform.localPosition.z >= 1.5)
        {
            pShield.transform.localPosition = new Vector3(0, 0, 1.5f);
        }
    }

}


/* void OnCollisionEnter(Collision c)
 {
     // force is how forcefully we will push the player away from the enemy.
     float force = 3;
 
     // If the object we hit is the enemy
     if (c.gameObject.tag == "enemy")
     {
         // Calculate Angle Between the collision point and the player
         Vector3 dir = c.contacts[0].point - transform.position;
         // We then get the opposite (-Vector3) and normalize it
         dir = -dir.normalized;
         // And finally we add force in the direction of dir and multiply it by force. 
         // This will push back the player
         GetComponent<Rigidbody>().AddForce(dir*force);
     }
 }*/
