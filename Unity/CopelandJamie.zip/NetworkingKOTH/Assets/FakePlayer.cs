﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FakePlayer : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.Rotate(2f, 0f, 0f);
        this.transform.GetChild(1).Rotate(0, 5f, 0);
	}
}
