﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Number : MonoBehaviour {
    float time = 1.0f;
	// Use this for initialization
	void Start () {
        this.transform.localScale *= 4;
	}
	
	// Update is called once per frame
	void Update () {
        time -= Time.deltaTime;
        this.transform.localScale -= new Vector3(0.05f, 0.05f, 0.05f);
	}
}
