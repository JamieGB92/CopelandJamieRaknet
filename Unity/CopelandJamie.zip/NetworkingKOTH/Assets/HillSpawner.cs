﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class HillSpawner : NetworkBehaviour {


    public GameObject hill;

	public override void OnStartServer () {
        spawnHill();
	}
	
	// Update is called once per frame
	

  
    void spawnHill()
    {
        Debug.Log("spawn hill enter");
        GameObject go = Instantiate(hill,this.transform);

        ClientScene.RegisterPrefab(go);

        NetworkServer.Spawn(go);


    }
}
