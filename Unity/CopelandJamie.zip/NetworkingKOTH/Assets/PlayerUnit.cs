﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

public class PlayerUnit : NetworkBehaviour {


    public float speed,rotSpeed,jumpforce,sheildforce;
    [SyncVar]
    public float playerID;
    [SyncVar]
    public bool isKing = false;
    [SyncVar]
    public int score;
    public bool isGrounded()
    {
        return Physics.Raycast(transform.position, -Vector3.up, this.GetComponent<Collider>().bounds.extents.y+.1f);
    }
    [SyncVar]
    public bool isReady =false;
    [SyncVar]
    public bool isPushing = false;
    [SyncVar]

   public bool isKnockedBack = false;
    public Text pName;
    public Vector3 direction;
    public GameObject networokRef;
    public Text NamePF;
    public Transform namePos;
    [SyncVar]
    public string pNom;
    [SyncVar(hook ="onChangeName")]
    public string pDname="Player";
    [SyncVar(hook = "OnColorChange")]
    public string pColor = "#ffffff";

    bool doOnce = false;
    bool doOnceB = false;
    float temp = .25f;
    float timer = .25f;

    void OnColorChange(string n)
    {
        pColor = n;
        Renderer rends = this.transform.GetChild(1).GetComponent<Renderer>();
       
        rends.material.SetColor("_Color",ColorFromHex(pColor));
        CmdChangePlayerColor(n);
    }
    [Command]
    public void CmdChangePlayerColor(string n)
    {
        pColor = n;
        Renderer rends = this.transform.GetChild(1).GetComponent<Renderer>();

        rends.material.SetColor("_Color", ColorFromHex(pColor));
    }

    void onChangeName(string n)
    {
        pDname = n;
        pName.text = pDname;
        this.name = pDname;
    }

    [Command]
    public void CmdChangeName(string n)
    {
        pDname = n;
        pName.text = pDname;
        this.name = pDname;
    }
    Color ColorFromHex(string hex)
    {
        hex = hex.Replace("0x", "");
        hex = hex.Replace("#", "");
        byte a = 255;
        byte r = byte.Parse(hex.Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
        byte g = byte.Parse(hex.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
        byte b = byte.Parse(hex.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);
        if(hex.Length==8)
        {
            a= byte.Parse(hex.Substring(4, 2), System.Globalization.NumberStyles.HexNumber);
        }
        return new Color(r, g, b, a);

    }
    private void OnGUI()
    {
        
        //if(isLocalPlayer)
        //{
        //    pDname = GUI.TextField(new Rect(25, 25, 100, 25),name);
        //    if(GUI.Button(new Rect(130,15,35,25),"Set"))
        //    {
        //        CmdChangeName(pDname);
        //    }
        //}
    }
    bool foop=false;

    public override void OnStartLocalPlayer()
    {
        //this.transform.GetChild(1).GetComponent<MeshRenderer>().material.color = Color.red;
       
    }
    public void Awake()
    {
        GameObject canvas = GameObject.FindWithTag("MainCanvas");
        Text pNameA = Instantiate(NamePF.GetComponent<Text>(), Vector3.zero, Quaternion.identity);
        pName = pNameA;
        pName.transform.SetParent(canvas.transform);
        pName.text = pDname + "|| Score :" + score;
        this.name = pDname;
    }
    // Use this for initialization
    void Start () {

        namePos = this.transform.GetChild(4).transform;
        playerID = Random.Range(0, 1000);
       // this.name = "Player " + playerID;
       
        this.transform.GetChild(0).gameObject.GetComponent<Sheild>().player = this.gameObject;
        if (!this.GetComponent<NetworkIdentity>().hasAuthority)
        {
            return;
        }
        if(isLocalPlayer)
        {
            Camera.main.transform.position = this.transform.position - this.transform.forward*2 + this.transform.up * 1.5f;
            Camera.main.transform.LookAt(this.transform.GetChild(3));
            Camera.main.transform.parent = this.transform;
        }

       

    }


    // Update is called once per frame
    void Update()
    {

        if (!this.GetComponent<NetworkIdentity>().hasAuthority)
        {
            return;
        }
        pName.text = pDname + "|| Score :" + score;
        Vector3 namepos = Camera.main.WorldToScreenPoint(namePos.position);
        pName.transform.position = namepos;
        //this.transform.GetChild(0).gameObject.GetComponent<Sheild>().playerPushing = isPushing;
        if (isPushing)
        {


            Rigidbody r = GetComponent<Rigidbody>();
            r.constraints = RigidbodyConstraints.FreezeAll;
            timer -= Time.deltaTime;
        }
        else
        {
            Rigidbody r = GetComponent<Rigidbody>();
            r.constraints = RigidbodyConstraints.None;
            r.constraints = RigidbodyConstraints.FreezeRotation;
            timer = temp;
        }
        movement();
        sheildPush();
        // Debug.Log(this.name+" "+isPushing);
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        if (isKing)
        {
            if (!doOnce)
            {
                GameObject.FindGameObjectWithTag("GameController").GetComponent<GameManager>().playerOnhill++;
                doOnce = true;
            }
            score++;
            doOnceB = false;
        }
        else if (!isKing)
        {
            if (!doOnceB)
            {

                {
                    GameObject.FindGameObjectWithTag("GameController").GetComponent<GameManager>().playerOnhill--;
                    doOnceB = true;
                }
            }
            doOnce = false;
        }

        if (Input.GetKeyDown(KeyCode.Q))
        {
            // Debug.Log(this.gameObject.name+"wuddup");
            if (!foop)
            {
                string n = this.name + "-Ready";
                pNom = n;
                isReady = true;
                CmdChangeReady(n);
                // foop = true;
            }

        }
        if (Input.GetKeyDown(KeyCode.K))
        {
            score++;
        }
    }
   




    void movement()
    {
        float z = Input.GetAxis("Vertical") * Time.deltaTime * speed;
        float x = Input.GetAxis("Horizontal") * Time.deltaTime * speed;
        float rotX = Input.GetAxis("Mouse X") * Time.deltaTime * rotSpeed;

        transform.Rotate(0, rotX, 0);
        transform.Translate(x, 0, z);
       if(Input.GetKeyDown(KeyCode.Space)&&isGrounded())
        {
            CmdJump();
        }
    }
    [Command]
    void CmdChangeReady(string n)
    {
        // if(isServer)
        Debug.Log("wuddup");
        isReady = true;
        // this.name = this.name + "-Ready";
        //this.GetComponent<PlayerUnit>().pNom = n;
       // this.GetComponent<Transform>().name = n;
     
            RpcChangeReady(n);
        
        
    }
    [ClientRpc]
    void RpcChangeReady(string n)
    {
        isReady = true;
        //this.GetComponent<PlayerUnit>().pNom = n;
        //this.GetComponent<Transform>().name = n;
        Debug.Log("wudduuuiiillp");
       // this.gameObject.name = this.name + "-Ready";
           
       
    }
    [Command]
    void CmdJump()
    {
        this.GetComponent<Rigidbody>().AddForce(Vector3.up * jumpforce, ForceMode.Impulse);
        if (!isLocalPlayer)
        {
            RpcJump();
        }
       // this.GetComponent<Rigidbody>().AddForce(Vector3.up * jumpforce, ForceMode.Impulse);
    }
    [ClientRpc]
    void RpcJump()
    {
        this.GetComponent<Rigidbody>().AddForce(Vector3.up *jumpforce, ForceMode.Impulse);
    }

    void sheildPush()
    {
        
        if (Input.GetMouseButton(0))
        {
            isPushing = true;
            
            this.transform.GetChild(0).transform.Translate(0, 0, speed * Time.deltaTime);
            if (this.transform.GetChild(0).transform.localPosition.z >= 1.5f)
            {
               
                this.transform.GetChild(0).GetComponent<BoxCollider>().center = new Vector3(0, 0, 0.06f);
                this.transform.GetChild(0).transform.localPosition = new Vector3(0, 0, 1.5f);
               // timer -= Time.deltaTime;
              //  Debug.Log(timer);
                if (timer < 0) { 
                this.transform.GetChild(0).GetComponent<BoxCollider>().center = new Vector3(0, 0, 0.03f);
                }
            }
        }
        if (!Input.GetMouseButton(0))
        {
            isPushing = false;
            this.transform.GetChild(0).transform.Translate(0, 0, -speed * Time.deltaTime);
            if (this.transform.GetChild(0).transform.localPosition.z <= 0.6f)
            {
                this.transform.GetChild(0).GetComponent<BoxCollider>().center = new Vector3(0, 0, 0.03f);
                isPushing = false;
                this.transform.GetChild(0).transform.localPosition = new Vector3(0, 0, 0.6f);
                this.transform.GetChild(0).transform.Translate(0, 0, 0);
            }
        }
    }

 
    


    [Command]
    public void CmdKnockBack(Vector3 direction)
    {
        this.GetComponent<Rigidbody>().AddForce(Vector3.up * 4F, ForceMode.Impulse);
        this.GetComponent<Rigidbody>().AddForce(direction * 4f, ForceMode.Impulse);
        if (!isLocalPlayer)
        {
            RpcKnockBack(direction);
        }
    }


    [ClientRpc]
    public void RpcKnockBack(Vector3 direction)
    {
        Debug.Log(this.name + " rpc  ");

       
        if (isGrounded())
        {
            this.GetComponent<Rigidbody>().AddForce(Vector3.up * 7F, ForceMode.Impulse);
            this.GetComponent<Rigidbody>().AddForce(direction * 7f, ForceMode.Impulse);
        }
            //CmdKnockBack(direction);
            //networokRef.GetComponent<PlayerObject>().knockedBack = false;
           // CmdKB2(direction);
    }
    
}
