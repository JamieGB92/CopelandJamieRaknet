﻿using UnityEngine;
using Prototype.NetworkLobby;
using System.Collections;
using UnityEngine.Networking;

public class NetworkLobbyHook : LobbyHook 
{
    public override void OnLobbyServerSceneLoadedForPlayer(NetworkManager manager, GameObject lobbyPlayer, GameObject gamePlayer)
    {
        LobbyPlayer lobby = lobbyPlayer.GetComponent<LobbyPlayer>();
        PlayerUnit Pu = gamePlayer.GetComponent<PlayerUnit>();

        Pu.pDname = lobby.playerName;
        Pu.pColor = ColorUtility.ToHtmlStringRGBA(lobby.playerColor);

      
    }
}
