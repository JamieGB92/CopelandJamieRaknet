﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
public class GameManager : NetworkBehaviour {

    [SyncVar]
    public float gameTime = 0;
    public GameObject HillPrefab,hill;
    [SyncVar]
    public int playerOnhill=0;
    public int playerId = 1;
    public GameObject[] Players;
    public GameObject winningPlayer;
    public int length=0;
    public NetworkManager nM;
    [SyncVar]
    bool gameWon = false;
    bool allPlayersReady()
    {
        for(int i=0;i<Players.Length;i++)
        {
            
            if (!Players[i].GetComponent<PlayerUnit>().isReady)
            {
                return false;
            }
        }
        return true;
    }
    
    Vector3 lastpos=new Vector3(0,0,0);
    public int numPlayers;
	// Use this for initialization
	public void Start () {

        GameObject.Find("Instructions").SetActive(false);
        nM = GameObject.Find("LobbyManager").GetComponent<NetworkManager>();
        playerOnhill = 0;
    }

    // Update is called once per frame
     void Update()
    {
        length = NetworkServer.connections.Count;
        Players = GameObject.FindGameObjectsWithTag("Player");
        numPlayers = Players.Length;

        if (length > 0 && allPlayersReady())
        {
            if (hill == null)
            {
                spwanHillAtnewPos();
            }
        }
        Debug.Log(allPlayersReady());
        for(int i=0; i<Players.Length; i++)
        {
            if(Players[i].GetComponent<PlayerUnit>().score>=1000)
            {
                string temp = Players[i].name;
               
                Players[i].name = temp + " is the winner";
                gameWon = true;
               
            }
        }
        if(gameWon)
        {
            for (int i = 0; i < Players.Length; i++)
            { 
                    PlayerPrefs.SetInt("Playe Score", Players[i].GetComponent<PlayerUnit>().score);
            }

            nM.ServerChangeScene("Lobby");
        }
    
      
    }
    
    public void spwanHillAtnewPos()
    {

        Vector3 newPos = new Vector3(Random.Range(-40, 40), 0, Random.Range(-40, 40));
        Vector3 offSet = new Vector3(10, 0, 10);
        Vector3 currentPlus = lastpos + offSet;
        Vector3 currentMinus = lastpos - offSet;
        if ((newPos.x <= currentPlus.x && newPos.z <= currentPlus.z)&&
            (newPos.x >= currentMinus.x && newPos.z >= currentMinus.z))
        { newPos = new Vector3(Random.Range(-40, 40), 0, Random.Range(-40, 40));
            Debug.Log("woot");
        }
            GameObject go = Instantiate(HillPrefab);
            NetworkServer.Spawn(go);
            hill = go;
            hill.transform.position = newPos;
            lastpos = newPos;
      
            //RpcspwanHillAtnewPos();
        
    }

    //[ClientRpc]
    //public void RpcspwanHillAtnewPos()
    //{
       
      
    //    GameObject go = Instantiate(HillPrefab);
    //    NetworkServer.Spawn(go);
    //    hill = go;
    //    hill.transform.position = newPos;
    //    lastpos = newPos;
        
    //}
}
