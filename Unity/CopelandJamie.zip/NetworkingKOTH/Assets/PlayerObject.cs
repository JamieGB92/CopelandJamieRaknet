﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class PlayerObject : NetworkBehaviour {

    GameObject mPlayerUnit;
   // [SyncVar(hook = "onPlayerNameChange")]
    public string PlayerName = "Anon";
    [SyncVar]
    public bool knockedBack = false;
    [SyncVar]
    public Vector3 direction;
    [SyncVar]
    bool donce = false;
 public GameObject PlayerUnitPrefab;
    float playerID = 0;
    // Use this for initialization
    void Start () {
        if(!isLocalPlayer)
        {
            Debug.Log("Sit");
            return;
        }
        //Instantiate(PlayerUnitPrefab);
        //command server to spawn  player object prefab
       
        playerID = Random.Range(0, 1000);
        PlayerName = "Player " + playerID;
        CmdspawnPlayer();

    }
   
    // Update is called once per frame

    void Update () {
        
        if(Input.GetKey(KeyCode.N)&&GetComponent<NetworkIdentity>().hasAuthority)
        {
            if (!donce)
            {
                CmdChangePlayerName(mPlayerUnit.name + "-Ready");
            }

            donce = true;
        }

        

	}
    

    void FixedUpdate()
    {
      
    }

    #region Commands->client to server
    [Command]
    void CmdspawnPlayer()
    {   
        
        GameObject go = Instantiate(PlayerUnitPrefab);
        go.name = PlayerName;
        go.transform.position = this.transform.position;
        go.transform.rotation = this.transform.rotation;
        go.GetComponent<PlayerUnit>().networokRef=this.gameObject;
        mPlayerUnit = go;
     
        NetworkServer.SpawnWithClientAuthority(go,connectionToClient);
       

    }

    [Command]
    void CmdChangePlayerName(string n)
    {
        PlayerName = n;
        mPlayerUnit.name = PlayerName;
        //gameObject.name = "network object for -" + PlayerName;
        if (!isLocalPlayer)
        {
            RpcChangePlayerName(PlayerName);
        }
       
    }
    #endregion

    #region RPCs->server to client
    [ClientRpc]
    void RpcChangePlayerName(string n)
    {
        mPlayerUnit.name = PlayerName;
       
    }

    #endregion

    #region KnockBack

    //[Command]
    //public void CmdKnockBack(Vector3 direction)
    //{
       
    //        Debug.Log("Client to server knockback");
    //        mPlayerUnit.GetComponent<Rigidbody>().AddForce(Vector3.up * 5f, ForceMode.Impulse);
    //        mPlayerUnit.GetComponent<Rigidbody>().AddForce(direction * 2, ForceMode.Impulse);
    //        RpcKnockBack(direction);
        
    //}

    //[ClientRpc]
    //public void RpcKnockBack(Vector3 direction)
    //{
      


    //        Debug.Log("server to client knockBack");
    //        mPlayerUnit.GetComponent<Rigidbody>().AddForce(Vector3.up * 5f, ForceMode.Impulse);
    //        mPlayerUnit.GetComponent<Rigidbody>().AddForce(direction * 2, ForceMode.Impulse);
        
    //}

    #endregion
}
