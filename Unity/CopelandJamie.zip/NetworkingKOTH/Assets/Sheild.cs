﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Sheild : MonoBehaviour {
     string playerName;
    public bool playerPushing;
    public GameObject player;
   public GameObject Target;
    private void Start()
    {
        playerName = player.name;
        Target = player.transform.GetChild(3).gameObject;
       // Debug.Log(playerName);

    }
    private void Update()
    {
        //Debug.Log(message: playerName + GetComponentInParent<PlayerUnit>().isPushing);
        //Debug.Log(playerName +" " + GameObject.Find(playerName).GetComponent<PlayerUnit>().isPushing);
    }
    void OnTriggerEnter(Collider other)
    {
       if(other.gameObject.name!=playerName&&other.gameObject.tag=="Player")
        {
            Debug.Log("colision det");

            #region old
            
                Vector3 dir = other.gameObject.transform.position - this.GetComponentInParent<Transform>().transform.position;
                dir = dir.normalized;
               // Debug.Log(playerName + " pushed " + other.gameObject.name);
                if (other.GetComponent<PlayerUnit>() == null)
                {
                     other.GetComponentInParent<PlayerUnit>().CmdKnockBack(dir);
                    //other.GetComponentInParent<PlayerUnit>().isKnockedBack = true;
               

                }
                else
                {
                   // other.GetComponent<PlayerUnit>().isKnockedBack = true;
                    other.GetComponent<PlayerUnit>().CmdKnockBack(dir);
            }
            
            #endregion
        }
    }

   



}





/*other.gameObject.GetComponent<PlayerUnit>().playerID!=this.GetComponentInParent<PlayerUnit>().playerID
*/
//Vector3 dir = other.gameObject.transform.position - this.GetComponentInParent<Transform>().transform.position;
//dir = dir.normalized;

//if (other.gameObject.GetComponent<PlayerUnit>() == null)
//{
//    other.gameObject.GetComponentInParent<PlayerUnit>().networokRef.GetComponent<PlayerObject>().knockedBack=true;
//    other.gameObject.GetComponentInParent<PlayerUnit>().networokRef.GetComponent<PlayerObject>().direction = dir;
//}
//else
//{
//    other.gameObject.GetComponent<PlayerUnit>().networokRef.GetComponent<PlayerObject>().knockedBack = true;
//    other.gameObject.GetComponent<PlayerUnit>().networokRef.GetComponent<PlayerObject>().direction = dir;
//}